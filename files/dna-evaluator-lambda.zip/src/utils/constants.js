module.exports = {
  SEQS: ["AAAA", "TTTT", "CCCC", "GGGG"],
  HTTP_SUCCESS_CODE: 200,
  HTTP_BUSSINES_CODE: 403,
  APPLICANTS_TABLE_NAME: "applicants",
  REGION_AWS: "us-east-1",
};
