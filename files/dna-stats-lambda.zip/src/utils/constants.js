module.exports = {
  APPLICANTS_TABLE_NAME: "applicants",
  REGION_AWS: "us-east-1",
  HTTP_SUCCESS_CODE: 200,
  HEADER: {
    "Content-Type": "application/json",
  },
};
